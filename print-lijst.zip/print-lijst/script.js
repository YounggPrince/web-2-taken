var Artist1 = {name: "Youngboy" , sterkepunt: "sterke en veel flows" , catagorie: "hiphop"};


var Artist2 = {name: "Gunna" , sterkepunt: "melodie" , catagorie: "hiphop/rb"};

var Artist3 = {name: "Kflock" , sterkepunt: "snel rappen", catagorie: "hiphop"};

var lijstArtist = [Artist1, Artist2, Artist3 ];
for (let Artist of lijstArtist) {
    console.log(Artist);
    }



